# finder.py

def getData():
    """Returns a list of topics."""
    topics = ["AI", "Machine Learning", "Deep Learning", "Neural Networks", "AI Chatbot"]
    return topics


def find(topics):
    """Prints all topics that include the string 'AI'."""
    for topic in topics:
        if "AI" in topic:
            print(topic)
