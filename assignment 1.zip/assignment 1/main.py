import finder


def main():
    topics = finder.getData()  # Call getData from finder
    finder.find(topics)        # Call find with the retrieved topics

if __name__ == "__main__":
    main()