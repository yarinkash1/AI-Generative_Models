# main.py
from machine import Machine  # Import the Machine class

def main():
    # Create an instance of the Machine
    machine1 = Machine("Lathe Machine")

    # Display the initial status of the machine
    machine1.status()

    # Try to operate the machine when it's off
    machine1.operate()

    # Turn the machine on and perform an operation
    machine1.turn_on()
    machine1.operate()

    # Display the machine's status again
    machine1.status()

    # Turn the machine off
    machine1.turn_off()

    # Display the final status of the machine
    machine1.status()

if __name__ == "__main__":
    main()
