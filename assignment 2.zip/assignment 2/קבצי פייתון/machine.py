class Machine:
    def __init__(self, name, power_status=False):
        self.name = name
        self.power_status = power_status
        self.operations_count = 0

    def turn_on(self):
        if not self.power_status:
            self.power_status = True
            print(f"{self.name} is now ON.")
        else:
            print(f"{self.name} is already ON.")

    def turn_off(self):
        if self.power_status:
            self.power_status = False
            print(f"{self.name} is now OFF.")
        else:
            print(f"{self.name} is already OFF.")

    def operate(self):
        if self.power_status:
            self.operations_count += 1
            print(f"{self.name} performed operation #{self.operations_count}.")
        else:
            print(f"Cannot operate. {self.name} is OFF.")

    def status(self):
        status = "ON" if self.power_status else "OFF"
        print(f"{self.name} is currently {status}. Operations performed: {self.operations_count}")
